/*
 * Spi.h
 *
 * Created: 10/21/2020 12:18:27 AM
 *  Author: DELL
 */ 


#ifndef SPI_H_
#define SPI_H_

#include "DIO_CFG.h"
//#include "Spi_HW.h"

/*typedef enum{
	SPR0=0,
	SPR1,
	CPHA,
	CPOL,
	MSTR,
	DORD,
	SPE,
	SPIE
}SPCR_Bits;

typedef enum{
	WCOL=6,
	SPIF
}SPSR_Bits;*/

void SPI_Init();
void SPI_Write(char data);
char SPI_Read();
char SPI_Receive();


#endif /* SPI_H_ */