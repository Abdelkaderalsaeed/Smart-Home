/*
* LCD.c
*
* Created: 10/2/2020 6:36:58 PM
*  Author: DELL
*/

#include "LCD.h"

void LCD_Init(){
	DIO_Write(LCD_RW,STD_Low);   // Write
	_delay_ms(25);
	LCD_CMD(0x33);
	_delay_ms(2);
	LCD_CMD(0x32);            // 4_Bit interface
	LCD_CMD(0x28);            // Function Set
	LCD_CMD(0x06);            // Entry mode Set
	LCD_CMD(0x0C);            // Display on				
    LCD_CMD(0x01);            // Clear LCD
	_delay_ms(2);
}
void LCD_CMD(Uint8 cmd){       // Send CMD
	
	LCD_DataReg = (LCD_DataReg & 0x0f) | (cmd & 0xf0);  //Send High Nipple
	DIO_Write(LCD_RS,STD_Low);
	DIO_Write(LCD_E,STD_High);
	_delay_ms(2);
	DIO_Write(LCD_E,STD_Low);
	
	_delay_ms(5);                                        //delay
	
	LCD_DataReg = (cmd<<4) | (LCD_DataReg & 0x0f);       //Send Low Nipple
	DIO_Write(LCD_RS,STD_Low);
	DIO_Write(LCD_E,STD_High);
	_delay_ms(2);
	DIO_Write(LCD_E,STD_Low);
}


void LCD_Char(Uint8 data){       // Send Data
	LCD_DataReg = (LCD_DataReg & 0x0f) | (data & 0xf0);  //Send High Nipple
	DIO_Write(LCD_RS,STD_High);
	DIO_Write(LCD_E,STD_High);
	_delay_ms(2);
	DIO_Write(LCD_E,STD_Low);
	
	_delay_ms(5);                                        //delay
	
	LCD_DataReg=(LCD_DataReg & 0x0f) | (data << 4);    //Send Low Nipple
	DIO_Write(LCD_RS,STD_High);
	DIO_Write(LCD_E,STD_High);
	_delay_ms(2);
	DIO_Write(LCD_E,STD_Low);
}

void LCD_String(char * string){
	Uint8 count=0;
	while(string[count] != '\0'){
		LCD_Char(string[count]);
		count++;
	}
}

void LCD_StarPOS(Uint8 line,Uint8 pos){
	Uint8 SendCmd;
	switch(line){
		case 1:
		SendCmd = 0x80 | (pos & 0x0F); //ff --> 0f | 0x80 -->0x8f
		LCD_CMD(SendCmd);
		break;
		case 2:
		SendCmd = 0xC0 | (pos & 0x0F); //ff --> 0f | 0xC0 -->0xCf
		LCD_CMD(SendCmd);
		break;
	}
}

void LCD_Custom_Char(Uint8 Loc,Uint8* Msg){
	if (Loc<8)
	{
		LCD_CMD(0x40+(Loc*8));
		for(Uint8 i=0;i<=7;i++){
			LCD_Char(Msg[i]);
		}
	}
}







