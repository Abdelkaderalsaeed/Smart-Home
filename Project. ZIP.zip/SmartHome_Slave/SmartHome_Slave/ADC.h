/*
 * ADC.h
 *
 * Created: 10/21/2020 12:17:46 AM
 *  Author: DELL
 */ 


#ifndef ADC_H_
#define ADC_H_


#include <avr/io.h>
#include "Bit Match.h"
#include "ADC_HW.h"

#define ADC_REFS0    6
#define ADC_REFS1    7
#define ADC_EN       7
#define ADC_CVS      6
#define ADC_INTFLAG  4
#define ADC_PS2      2
#define ADC_PS1      1
#define ADC_PS0      0

void ADC_Init(void);
unsigned short ADC_Read (unsigned char channel);


#endif /* ADC_H_ */