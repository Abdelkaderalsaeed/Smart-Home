/*
 * Spi.c
 *
 * Created: 10/21/2020 12:18:08 AM
 *  Author: DELL
 */ 

#include <avr/io.h>
#include "SPI.h"


void SPI_Init()					
{
	// Make MOSI, SCK, SS as Input pin   And   Make MISO pin as Output pin  in ( DIO_CFG.c )
    DIO_Init();
	SPCR = (1<<SPE);  			         
}
void SPI_Write(char data)		
{
	SPDR = data;			
	while(!(SPSR & (1<<SPIF)));	
}
char SPI_Read()				
{
	SPDR = 0xFF;
	while(!(SPSR & (1<<SPIF)));	
	return(SPDR);			
}
char SPI_Receive()			
{
	while(!(SPSR & (1<<SPIF)));	
	return(SPDR);			
}
