/*
* SmartHome_Slave.c
*
* Created: 10/21/2020 12:14:39 AM
* Author : Abdelkader Alsaeed Abdelkader
*/

//#include <avr/io.h>
#include <stdlib.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include "ADC.h"
#include "SPI.h"
#include "LCD.h"

int main(void){
	
	SPI_Init();
	LCD_Init();
	ADC_Init();
	OCR0 =0;
	TCCR0 |=(1<<COM01)|(1<<CS00)|(1<<CS01)|(1<<WGM00);
	
	unsigned short temp=0;
	char array[16];
	
	unsigned char count=0;
	char var;
	char MOF=0;
	while (1)
	{
		var=SPI_Receive();
		switch(var){
			case '1':
			DIO_Write(DIO_ChannelC0,STD_High);
			break;
			
			case '2':
			DIO_Write(DIO_ChannelC0,STD_Low);
			break;
			
			case '3':
			temp=ADC_Read(0);
			temp /=4;
			itoa(temp,array,10);
			LCD_StarPOS(1,0);
			LCD_CMD(0x01);
			LCD_String("The Temperature=");
			LCD_StarPOS(2,0);
			LCD_String(array);
			break;
			
			case '4':
			LCD_CMD(0x01);
			DIO_Write(DIO_ChannelC6,STD_High);
			LCD_String(" Motor Speed 0%");
			MOF=1;
			break;
			
			case '5':
			DIO_Write(DIO_ChannelC6,STD_Low);
			LCD_CMD(0x01);
			LCD_String(" Motor Speed 0%");
			OCR0=0;
			MOF=0;
			break;
			
			case '+':
			if (MOF==0)
			{
				LCD_CMD(0x01);
				LCD_String("Motor is OFF!?");
			}
			else{
			count++;
			switch(count)
			{
				case 1:
				OCR0 =51;
				LCD_CMD(0x01);
				LCD_String("Motor Speed 20%");
				break;
				
				case 2:
				OCR0 =102;
				LCD_CMD(0x01);
				LCD_String("Motor Speed 40%");
				break;
				
				case 3:
				OCR0 =153;
				LCD_CMD(0x01);
				LCD_String("Motor Speed 60%");
				break;
				
				case 4:
				OCR0 =204;
				LCD_CMD(0x01);
				LCD_String("Motor Speed 80%");
				break;
				
				case 5:
				OCR0 =255;
				LCD_CMD(0x01);
				LCD_String("Motor Speed 100%");
				break;
				}
				if (count>5)
				{
					count=5;
				}
			}
				break;
				
				case '-':
				if (MOF==0)
				{
					LCD_CMD(0x01);
					LCD_String("Motor is OFF!?");
				}
				else{
				count = count-1;
				
				switch(count)
				{
					case 0:
					OCR0 =0;
					LCD_CMD(0x01);
					LCD_String("MOTOR Speed 0 ");
					break;
					
					case 1:
					OCR0 =51;
					LCD_CMD(0x01);
					LCD_String("Motor Speed 20%");
					break;
					
					case 2:
					OCR0 =102;
					LCD_CMD(0x01);
					LCD_String("Motor Speed 40%");
					break;
					
					case 3:
					OCR0 =153;
					LCD_CMD(0x01);
					LCD_String("Motor Speed 60%");
					break;
					
					case 4:
					OCR0 =204;
					LCD_CMD(0x01);
					LCD_String("Motor Speed 80%");
					break;
					
					case 5:
					OCR0 =255;
					LCD_CMD(0x01);
					LCD_String("Motor Speed 100%");
					break;
				}
					if(count < 0){
						count = 0;
					}
				}
					break;
				}
			}
		}
	
