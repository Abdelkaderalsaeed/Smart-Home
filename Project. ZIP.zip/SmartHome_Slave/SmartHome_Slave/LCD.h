/*
 * LCD.h
 *
 * Created: 10/2/2020 6:37:18 PM
 *  Author: DELL
 */ 


#ifndef LCD_H_
#define LCD_H_
  
#include "DIO_CFG.h"

#define  F_CPU 16000000UL  
#include <util/delay.h> 
 
#define LCD_RS DIO_ChannelB1
#define LCD_RW DIO_ChannelB2
#define LCD_E  DIO_ChannelB0

#define LCD_DataReg PORTA_Reg
#define LCD_ControlReg PORTB_Reg

void LCD_Init();
void LCD_CMD(Uint8 cmd);
void LCD_Char(Uint8 data);
void LCD_String(char * string);
void LCD_StarPOS(Uint8 line,Uint8 pos);
void LCD_Custom_Char(Uint8 Loc,Uint8* Msg);

#endif /* LCD_H_ */