/*
 * ADC_HW.h
 *
 * Created: 10/21/2020 12:36:11 AM
 *  Author: DELL
 */ 


#ifndef ADC_HW_H_
#define ADC_HW_H_


#define ADC_MUX       (*((volatile unsigned char*)0x27))
#define ADC_CTRL_STAT (*((volatile unsigned char*)0x26))
#define ADC_HIGH_BYTE (*((volatile unsigned char*)0x25))
#define ADC_LOW_BYTE  (*((volatile unsigned char*)0x24))


#endif /* ADC_HW_H_ */