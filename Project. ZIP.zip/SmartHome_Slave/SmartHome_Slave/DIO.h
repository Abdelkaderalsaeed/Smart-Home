/*
 * DIO.h
 *
 * Created: 10/1/2020 1:00:37 PM
 *  Author: DELL
 */ 


#ifndef DIO_H_
#define DIO_H_

#include "Bit Match.h"
#include "STD Types.h"
#include "DIO_Types.h"
#include "DIO_HW.h"

void DIO_Write (DIO_ChannelTypes ChannelId,STD_LevelTypes Level );





#endif /* DIO_H_ */