/*
 * STD_Types.h
 *
 * Created: 10/1/2020 12:24:43 PM
 *  Author: DELL
 */ 


#ifndef STD TYPES_H_
#define STD TYPES_H_


typedef unsigned char  Uint8;
typedef enum {
	STD_Low=0,
	STD_High
	}STD_LevelTypes;



#endif /* STD TYPES_H_ */