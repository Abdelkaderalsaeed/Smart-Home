/*
 * Bit_Match.h
 *
 * Created: 10/1/2020 11:22:31 AM
 *  Author: DELL
 */ 


#ifndef BIT MATCH_H_
#define BIT MATCH_H_

#define SetBit(Reg,Bit) (Reg|=(1<<Bit))
#define ClearBit(Reg,Bit) (Reg&=~(1<<Bit))
#define ToggleBit(Reg,Bit) (Reg^=(1<<Bit))
#define GetBit(Reg,Bit) ((Reg>>Bit)&1)

#endif /* BIT MATCH_H_ */