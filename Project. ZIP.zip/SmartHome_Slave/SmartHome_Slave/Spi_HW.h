/*
 * Spi_HW.h
 *
 * Created: 10/21/2020 12:04:48 AM
 *  Author: DELL
 */ 


#ifndef SPI_HW_H_
#define SPI_HW_H_

#define SPCR  (*( (volatile Uint8 *)0x2D))
#define SPSR  (*( (volatile Uint8 *)0x2E))
#define SPDR  (*( (volatile Uint8 *)0x2F))

#endif /* SPI_HW_H_ */