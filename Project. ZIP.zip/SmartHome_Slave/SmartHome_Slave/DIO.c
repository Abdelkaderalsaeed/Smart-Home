/*
* DIO.c
*
* Created: 10/1/2020 1:01:19 PM
*  Author: DELL
*/

# include "DIO.h"

void DIO_Write (DIO_ChannelTypes ChannelId,STD_LevelTypes Level ){
	DIO_PortTypes Portx = ChannelId/8;
	DIO_ChannelTypes BitNumber = ChannelId%8;
	switch(Portx){
		case DIO_PORTA:
		if(Level == STD_High){
			SetBit(PORTA_Reg,BitNumber);
		}
		else{
			ClearBit(PORTA_Reg,BitNumber);
		}
		break;
		case DIO_PORTB:
		if(Level == STD_High){
			SetBit(PORTB_Reg,BitNumber);
		}
		else{
			ClearBit(PORTB_Reg,BitNumber);
		}
		break;
		case DIO_PORTC:
		if(Level == STD_High){
			SetBit(PORTC_Reg,BitNumber);
		}
		else{
			ClearBit(PORTC_Reg,BitNumber);
		}
		break;
		case DIO_PORTD:
		if(Level == STD_High){
			SetBit(PORTD_Reg,BitNumber);
		}
		else{
			ClearBit(PORTD_Reg,BitNumber);
		}
		break;
	}
	
	
	
}