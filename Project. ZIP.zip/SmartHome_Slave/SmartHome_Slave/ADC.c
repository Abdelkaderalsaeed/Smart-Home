/*
 * ADC.c
 *
 * Created: 10/21/2020 12:17:34 AM
 *  Author: DELL
 */ 

#include "ADC.h"
void ADC_Init(void)
{
	SetBit(ADC_MUX,ADC_REFS0);
	SetBit(ADC_MUX,ADC_REFS1);
	SetBit(ADC_CTRL_STAT,ADC_EN);
	SetBit(ADC_CTRL_STAT,ADC_PS2);
	SetBit(ADC_CTRL_STAT,ADC_PS1);
	SetBit(ADC_CTRL_STAT,ADC_PS0);
}
unsigned short ADC_Read (unsigned char channel)
{
	unsigned short data =0;
	ADC_MUX=(ADC_MUX & (0xE0))|(channel & (0x1F));
	SetBit(ADC_CTRL_STAT,ADC_CVS);
	while(!(ADC_CTRL_STAT &(1<<ADC_INTFLAG)));
	ADC_CTRL_STAT |=(1<<ADC_INTFLAG);
	data =ADC_LOW_BYTE;
	data |=(ADC_HIGH_BYTE<<8);
	return data;
}