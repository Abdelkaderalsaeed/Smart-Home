/*
* DIO_CFG.c
*
* Created: 10/1/2020 1:30:54 PM
*  Author: DELL
*/

#include "DIO_CFG.h"

const DIO_PinCFG Channelcfg[]={
	//PORTA
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	//PORTB
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High}, 
	// Make MOSI, SCK, SS as Output pin   And   Make MISO pin as input pin	
	{Output,STD_High},    //SS
	{Output,STD_High},    //MOSI
	{Input,STD_High},     //MISO
	{Output,STD_High},    //SCK
	//PORTC
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	{Output,STD_High},
	
};

void DIO_Init(){
	DIO_PortTypes Portx;
	DIO_ChannelTypes BitNumber;
	Uint8 count;
	for(count=DIO_ChannelA0;count<PINCOUNT;count++){
		Portx = count/8;
		BitNumber = count%8;
		switch(Portx){
			case DIO_PORTA:
			if(Channelcfg[count].ChannelDir == Output){
				SetBit(DDRA_Reg,BitNumber);
			}
			else{
				ClearBit(DDRA_Reg,BitNumber);
			}
			break;
			case DIO_PORTB:
			if(Channelcfg[count].ChannelDir == Output){
				SetBit(DDRB_Reg,BitNumber);
			}
			else{
				ClearBit(DDRB_Reg,BitNumber);
			}
			break;
			case DIO_PORTC:
			if(Channelcfg[count].ChannelDir == Output){
				SetBit(DDRC_Reg,BitNumber);
			}
			else{
				ClearBit(DDRC_Reg,BitNumber);
			}
			break;
			case DIO_PORTD:
			if(Channelcfg[count].ChannelDir == Output){
				SetBit(DDRD_Reg,BitNumber);
			}
			else{
				ClearBit(DDRD_Reg,BitNumber);
			}
			break;
		}
	}
}
