/*
 * Uart_HW.h
 *
 * Created: 10/20/2020 11:36:22 PM
 *  Author: DELL
 */ 


#ifndef UART_HW_H_
#define UART_HW_H_

#include "STD Types.h"

#define UART_DataReg                (*((volatile Uint8*)0x2C))  //UDR

#define UART_CTRSTATReg_A           (*((volatile Uint8*)0x2B))  //UCSRA

#define UART_CTRSTATReg_B           (*((volatile Uint8*)0x2A))  //UCSRB

#define BaudRate_Low_Reg            (*((volatile Uint8*)0x29))  //UBRRL

#define UART_CTRSTATReg_C           (*((volatile Uint8*)0x40))  //UBRRH &UCSRC

#endif /* UART_HW_H_ */