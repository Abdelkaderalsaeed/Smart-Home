/*
* SmartHome_Master.c
*
* Created: 10/20/2020 10:33:18 PM
* Author : Abdelkader Alsaeed Abdelkader
*/


#define F_CPU 16000000UL
#include <util/delay.h>
#include "SPI.h"
#include "Uart.h"
#include "LCD.h"

int main(void)
{
	SPI_Init();
	UART_Init();
	LCD_Init();
	
	LCD_String(" Welcome in My");
	LCD_StarPOS(2,0);
	LCD_String("  Smart Home");
	DIO_Write(DIO_ChannelB4,STD_Low);
	
	while (1)
	{
		switch(UART_Recieve()){
			case '1':
			SPI_Write('1');
			LCD_StarPOS(2,0);
			LCD_CMD(0x01);
			LCD_String("   LED is ON  ");
			break;
			
			case '2':
			SPI_Write('2');
			LCD_StarPOS(2,0);
			LCD_CMD(0x01);
			LCD_String("   LED is OFF  ");
			break;
			
			case '3':
			SPI_Write('3');
			LCD_CMD(0x01);
			LCD_StarPOS(1,0);
			LCD_String("    Reading");
			LCD_StarPOS(2,0);
			LCD_String("  Temperature");
			break;
			
			case '4':
			SPI_Write('4');
			LCD_CMD(0x01);
			LCD_String("  Motor is ON  ");
			break;
			
			case '5':
			SPI_Write('5');
			LCD_CMD(0x01);
			LCD_String("  Motor is OFF  ");
			break;
			
			case '+':
			SPI_Write('+');
			LCD_CMD(0x01);
			LCD_String("   Motor is ");
			LCD_StarPOS(2,0);
			LCD_String("  Accelerated  ");
			break;
			
			case '-':
			SPI_Write('-');
			LCD_CMD(0x01);
			LCD_String("   Motor is ");
			LCD_StarPOS(2,0);
			LCD_String("  Decelerated");
			break;
		}
	}
}

