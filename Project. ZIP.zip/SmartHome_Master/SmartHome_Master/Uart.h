/*
 * Uart.h
 *
 * Created: 10/20/2020 10:41:31 PM
 *  Author: DELL
 */ 


#ifndef UART_H_
#define UART_H_

#include "Bit Match.h"
#include "Uart_HW.h"

#define F_CPU    16000000UL
#define Baudrate 9600
#ifndef DoubleSpeed
#define MyUBBR           ((F_CPU/(16UL*Baudrate))-1)
#else
#define MyUBBR           ((F_CPU/(8UL*Baudrate))-1)
#endif
#define Trans_EN             3
#define Recieve_EN           4
#define Reg_Select           7
#define UART_CZ1             2
#define UART_CZ0             1
#define UART_DataReg_EM      5
#define UART_Recomp          7
void UART_Init(void);
void UART_Send(unsigned char data);
unsigned char UART_Recieve(void);
void UART_Send_String(char* string);




#endif /* UART_H_ */