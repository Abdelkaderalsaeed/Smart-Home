/*
 * Spi.h
 *
 * Created: 10/20/2020 10:40:46 PM
 *  Author: DELL
 */ 


#ifndef SPI_H_
#define SPI_H_


#include "Spi_HW.h"
#include "DIO_CFG.h"

typedef enum{
	SPR0=0,
	SPR1,
	CPHA,
	CPOL,
	MSTR,
	DORD,
	SPE,
	SPIE
}SPCR_Bits;

typedef enum{
	WCOL=6,
	SPIF
}SPSR_Bits;

void SPI_Init();	
void SPI_Write(char data);
char SPI_Read();


#endif /* SPI_H_ */