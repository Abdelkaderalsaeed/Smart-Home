/*
 * Spi.c
 *
 * Created: 10/20/2020 10:40:26 PM
 *  Author: DELL
 */ 
//#include "avr//io.h"
#include "SPI.h"

void SPI_Init()					 
{
	// Make MOSI, SCK, SS as Output pin   And   Make MISO pin as input pin  in ( DIO_CFG.c )
	DIO_Init();
	DIO_Write(DIO_ChannelB4,STD_High);      
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);	
	//SPSR &= ~(1<<SPI2X);			         
}
void SPI_Write(char data)		
{
	SPDR = data;			
	while(!(SPSR & (1<<SPIF)));	
}
char SPI_Read()				
{
	SPDR = 0xFF;
	while(!(SPSR & (1<<SPIF)));	
	return(SPDR);			
}